"""
GUI package for Agentic Browser.
"""

from .main_window import MainWindow, run_gui

__all__ = ["MainWindow", "run_gui"]
